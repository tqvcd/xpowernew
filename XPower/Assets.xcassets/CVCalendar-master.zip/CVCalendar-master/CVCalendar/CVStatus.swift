//
//  CVStatus.swift
//  CVCalendar
//
//  Created by 최완복 on 2016. 7. 28..
//  Copyright © 2016년 GameApp. All rights reserved.
//

import Foundation

@objc public enum CVStatus: Int {
    case In, Out, Disabled, Selected, Highlighted
}